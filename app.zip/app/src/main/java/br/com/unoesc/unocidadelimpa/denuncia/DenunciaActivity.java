package br.com.unoesc.unocidadelimpa.denuncia;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import br.com.unoesc.unocidadelimpa.R;
import br.com.unoesc.unocidadelimpa.gps.GpsService;

public class DenunciaActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {
   TextView data, categoria, descricao,longitude,latitude;
    ImageView ivFoto;
    //instancia gps
    GpsService gpsService = new GpsService(this);
    Denuncia denuncia;
    DenunciaDAO denunciaDAO;
    Bitmap bmimage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_denuncia);

        //cria seta de voltar na tela
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        categoria = (TextView) findViewById(R.id.activity_denuncia_tvCategoria);
        descricao = (TextView) findViewById(R.id.activity_denuncia_tvDescricao);
        latitude = (TextView) findViewById(R.id.activity_denuncia_tvLatitude);
        longitude = (TextView) findViewById(R.id.activity_denuncia_tvLongitude);
        data= (TextView) findViewById(R.id.activity_denuncia_tvData);



        Intent it=getIntent();
        if (it!=null) {
            denuncia = new Denuncia();
            denunciaDAO = new DenunciaDAO(this);
            denuncia = denunciaDAO.buscar(it.getStringExtra(Denuncia.ID));

            categoria.setText(denuncia.getCategoria());
            descricao.setText(denuncia.getDescricao());
            latitude.setText(denuncia.getLatitude());
            longitude.setText(denuncia.getLongitude());
            data.setText(denuncia.getData());

            //decodifica imagem
            ivFoto=(ImageView)findViewById(R.id.activity_denuncia_ivFoto);
            byte[] bytarray = Base64.decode(denuncia.getFoto(), Base64.DEFAULT);
            bmimage= BitmapFactory.decodeByteArray(bytarray, 0 ,bytarray.length);
            ivFoto.setImageBitmap(bmimage);
            ivFoto.setOnClickListener(this);
        }
        MapFragment  mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
        //recupera a informação selecionada
        //data = (EditText) findViewById(R.id.activity_denuncia_tvData);


        //pega posição do gps
        gpsService = new GpsService(this);
    }




    //ação seta voltar
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    //metodo que mexe no mapa
    @Override
    public void onMapReady(GoogleMap map) {




        //pega posição do gps e salva

        LatLng latLng = new LatLng(gpsService.getLatitude(),gpsService.getLongitude());

            //ponto 2  //cria latitude e longitude para a posição
      //  Double lat1 = Double.valueOf("-26.8758271");
      //  Double lon1 = Double.valueOf("-52.4047007");
      //  LatLng latLng1 = new LatLng(lat1, lon1);

        //cria marcador
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.title("teste");
        markerOptions.snippet("decrição");
        markerOptions.position(latLng);

      //  MarkerOptions markerOptions1 = new MarkerOptions();
      //  markerOptions1.title("teste");
      //  markerOptions1.snippet("decrição");
      //  markerOptions1.position(latLng1);

            //cria linha do ponto 1 ao 2
       // PolylineOptions linha = new PolylineOptions();
      //  linha.add(latLng);
      //  linha.add(latLng1);
     //   linha.color(Color.BLUE);


        //mostra tua localização ponto azul
       // map.setMyLocationEnabled(true);
        //move a camera e zoom para ponto expecifico
       map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
        map.addMarker(markerOptions);



    }
   //metodocliaca na foto e maximiza
    @Override
    public void onClick(View view) {
        final Dialog  dialog= new Dialog(this);
        dialog.setContentView(R.layout.dialog_foto);

        dialog.setTitle("Teste");
        ImageView ifoto = (ImageView) dialog.findViewById(R.id.dialog_foto_imfoto);
        ifoto.setImageBitmap(bmimage);
        dialog.show();
    }
}
