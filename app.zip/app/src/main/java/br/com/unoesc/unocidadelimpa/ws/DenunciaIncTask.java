package br.com.unoesc.unocidadelimpa.ws;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;


import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import br.com.unoesc.unocidadelimpa.denuncia.Denuncia;
import br.com.unoesc.unocidadelimpa.denuncia.DenunciaCADActivity;

/**
 * Created by vagner on 09/12/16.
 */
public class DenunciaIncTask extends AsyncTask<Denuncia,Void,Void> {
    ProgressDialog dialog;
    DenunciaCADActivity activity;

    public DenunciaIncTask(DenunciaCADActivity activity){
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {
        dialog=new ProgressDialog(this.activity);
        dialog.setTitle("Teste");
        dialog.setMessage("Sincronizando");
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.show();

    }

    @Override
    protected Void doInBackground(Denuncia... denuncias) {


        String url= "http://192.168.43.162//www/cidadelimpa/ws/incluidenuncia.php";
        DefaultHttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);
        Gson gs = new Gson();
        String objJson = gs.toJson(denuncias[0]);
        try{
            StringEntity entity = new StringEntity(objJson);

            post.setEntity(entity);
            post.setHeader("Content-type", "application/json");
            post.setHeader("Accept","application/json");
            client.execute(post);
            Log.i("unoesc",objJson);
            this.publishProgress();
        }
        catch(Exception e){
            e.printStackTrace();

        }finally {
            dialog.dismiss();
        }

        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
        activity.finalizar();
    }
}
