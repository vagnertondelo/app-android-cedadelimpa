package br.com.unoesc.unocidadelimpa.denuncia;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

import br.com.unoesc.unocidadelimpa.R;


public class DenunciaListaFragment extends Fragment implements AdapterView.OnItemClickListener {

    List<Denuncia> denuncias;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_denuncia_lista,container,false);
        //lista
       ListView listView = (ListView) view.findViewById(R.id.fragment_denuncia_list_listview);
        // mostra vazio se não tiver nada
        listView.setEmptyView(view.findViewById(android.R.id.empty));
        //botaõa para chamar a tela denuncia
        listView.setOnItemClickListener(this);


        DenunciaDAO denunciaDAO = new DenunciaDAO(getActivity());
         denuncias = denunciaDAO.listar();

        DenunciaListAdapter adapter = new DenunciaListAdapter(getActivity(),R.layout.fragment_denuncia_list_item,denuncias);
        listView.setAdapter(adapter);

        return view;
    }

//onClik para chamar a tela nova
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
       Denuncia denuncia =  denuncias.get(position);

        Intent it=new Intent(getActivity(),DenunciaActivity.class);
        String id1 = String.valueOf(denuncia.getId());
        it.putExtra(Denuncia.ID,id1);
        startActivityForResult(it,1);

    }
}
