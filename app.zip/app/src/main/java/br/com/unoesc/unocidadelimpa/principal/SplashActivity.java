package br.com.unoesc.unocidadelimpa.principal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import br.com.unoesc.unocidadelimpa.R;
import br.com.unoesc.unocidadelimpa.sqlite.BancoDados;

public class SplashActivity extends AppCompatActivity {

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        db =  BancoDados.getDB(this);


          // delay de tempo de 3 segundos para chamar tela principal
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
             //abre tela
                Intent it=new Intent(SplashActivity.this,PrincipalActivity.class);

                //só abre a tela
                startActivity(it);

                //recupera parametro da tela que for fechada quando chamar a outra
                //quando voltar a tela tera que obter novos valores
                //quando presica atuliazar list por exemplo ou valores
                // vc cadastra qual volta a tela de lista ele atualiza
                startActivityForResult(it,1);
            }
        },3000);

    }

}
