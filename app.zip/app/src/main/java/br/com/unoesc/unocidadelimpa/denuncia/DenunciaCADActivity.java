package br.com.unoesc.unocidadelimpa.denuncia;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.util.Date;

import br.com.unoesc.unocidadelimpa.R;
import br.com.unoesc.unocidadelimpa.gps.GpsService;
import br.com.unoesc.unocidadelimpa.ws.DenunciaIncTask;

public class DenunciaCADActivity extends AppCompatActivity {


    private TextView tvData;
    private EditText edtCategoria,edtDescricao;
    private ImageView imFoto;
    private DenunciaDAO denunciaDAO;
    private GpsService gpsService;

    //string para salvar foto no banco
    String strFoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_denuncia_cad);

        //cria seta de voltar na tela
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        edtCategoria = (EditText)findViewById(R.id.denuncia_cad_edtcategoria);
        edtDescricao =(EditText)findViewById(R.id.denuncia_cad_edtdescricao);

        imFoto=(ImageView) findViewById(R.id.denuncia_cad_imFoto);
          //implementa a data
        tvData = (TextView) findViewById(R.id.denuncia_cad_edtdata);
        String currentDateTimeString = DateFormat.getDateInstance().format(new Date());
        tvData.setText("" + currentDateTimeString);


        denunciaDAO = new DenunciaDAO(this);
        gpsService = new GpsService(this);
    }
    public void finalizar(){
        finish();
    }

    //ação seta voltar
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
               // finish();
                finalizar();
                break;
        }
        return true;
    }

    public void salvarDenuncia(View v){
        Denuncia denuncia = new Denuncia();
        denuncia.setCategoria(edtCategoria.getText().toString());
        denuncia.setDescricao(edtDescricao.getText().toString());
        denuncia.setData(tvData.getText().toString());
        denuncia.setFoto(strFoto);
        denuncia.setLongitude(String.valueOf(gpsService.getLongitude()));
        denuncia.setLatitude(String.valueOf(gpsService.getLatitude()));


        denunciaDAO.salvar(denuncia);

        //executa tesk para mandar para o web service
        DenunciaIncTask task = new DenunciaIncTask(this);
        task.execute(denuncia);

        Toast.makeText(getApplicationContext(), "Denuncia Salva", Toast.LENGTH_LONG).show();
        finish();


    }
    //implementa a foto com bitmap
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

       if (data != null) {

           Bundle bundle = data.getExtras();
           Bitmap bitmap = (Bitmap) bundle.get("data");

           imFoto.setImageBitmap(bitmap);

           //converte a foto em estrig para salvar
           ByteArrayOutputStream baos = new ByteArrayOutputStream();
           bitmap.compress(Bitmap.CompressFormat.PNG,100,baos);
           byte[] bytes = baos.toByteArray();
           strFoto = Base64.encodeToString(bytes,Base64.DEFAULT);
       }
    }

    public void capturarFoto(View v){

        Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(it,0);

    }






}
