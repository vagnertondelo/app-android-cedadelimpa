package br.com.unoesc.unocidadelimpa.denuncia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import br.com.unoesc.unocidadelimpa.sqlite.BancoDados;

/**
 * Created by vagner on 16/11/16.
 */
public class DenunciaDAO {


    SQLiteDatabase db;

    public DenunciaDAO(Context context){
        db = BancoDados.getDB(context);


    }


    public void salvar(Denuncia denuncia){
        ContentValues values = new ContentValues();

        values.put(Denuncia.CATEGORIA,denuncia.getCategoria());
        values.put(Denuncia.DESCRICAO,denuncia.getDescricao());
        values.put(Denuncia.LATITUDE,denuncia.getLatitude());
        values.put(Denuncia.LONGITUDE,denuncia.getLongitude());
        values.put(Denuncia.FOTO,denuncia.getFoto());
        values.put(Denuncia.DATA,denuncia.getData());
        db.insert(Denuncia.TABELA,null,values);
    }

    public void alterar(Denuncia denuncia){
        ContentValues values = new ContentValues();
        values.put(Denuncia.CATEGORIA,denuncia.getCategoria());
        values.put(Denuncia.DESCRICAO,denuncia.getDescricao());
        values.put(Denuncia.DATA,denuncia.getDescricao());
        values.put(Denuncia.LATITUDE,denuncia.getLatitude());
        values.put(Denuncia.LONGITUDE,denuncia.getLongitude());
        values.put(Denuncia.FOTO,denuncia.getFoto());

        String id = String.valueOf(denuncia.getId());
        String[] whereArgs = new String[]{id};

        db.update(Denuncia.TABELA,values,Denuncia.ID+"= ?",whereArgs);
    }
    public void excluir(String id){
        String[] whereArgs = new String[]{id};
        db.delete(Denuncia.TABELA,Denuncia.ID+"= ?",whereArgs);
    }
    public Denuncia buscar(String id) {


        String[] whereArgs = new String[]{id};

        Cursor c = db.query(Denuncia.TABELA, Denuncia.COLUNAS, Denuncia.ID + "= ?", whereArgs, null, null, null);

        if (c.moveToFirst()) {


            Denuncia denuncia = new Denuncia();
            denuncia.setId(c.getLong(c.getColumnIndex(Denuncia.ID)));
            denuncia.setCategoria(c.getString(c.getColumnIndex(Denuncia.CATEGORIA)));
            denuncia.setDescricao(c.getString(c.getColumnIndex(Denuncia.DESCRICAO)));
            denuncia.setFoto(c.getString(c.getColumnIndex(Denuncia.FOTO)));
            denuncia.setLatitude(c.getString(c.getColumnIndex(Denuncia.LATITUDE)));
            denuncia.setLongitude(c.getString(c.getColumnIndex(Denuncia.LONGITUDE)));
            denuncia.setData(c.getString(c.getColumnIndex(Denuncia.DATA)));


            return denuncia;
        }
        else{
            return null;
        }
        }



    public List<Denuncia> listar(){


        //ultimo null é a ordem da lista sempre com o espaço depoois do aspas
        Cursor c = db.query(Denuncia.TABELA,Denuncia.COLUNAS,null,null,null,null,Denuncia.ID+" desc");

        List<Denuncia> denuncias = new ArrayList<Denuncia>();
        if(c.moveToFirst()){
            do{
                Denuncia  denuncia = new Denuncia();
                denuncia.setId(c.getLong(c.getColumnIndex(Denuncia.ID)));
                denuncia.setCategoria(c.getString(c.getColumnIndex(Denuncia.CATEGORIA)));
                denuncia.setDescricao(c.getString(c.getColumnIndex(Denuncia.DESCRICAO)));
                denuncia.setFoto(c.getString(c.getColumnIndex(Denuncia.FOTO)));
                denuncia.setLatitude(c.getString(c.getColumnIndex(Denuncia.LATITUDE)));
                denuncia.setLongitude(c.getString(c.getColumnIndex(Denuncia.LONGITUDE)));
                denuncia.setData(c.getString(c.getColumnIndex(Denuncia.DATA)));

                Log.i("lista",denuncia.getCategoria());
                Log.i("lista",denuncia.getDescricao());
                Log.i("lista",denuncia.getFoto());
                Log.i("lista",denuncia.getLatitude());
                Log.i("lista",denuncia.getLongitude());


                denuncias.add(denuncia);
            }while (c.moveToNext());
        }
        return denuncias;
    }
   // lista com filtro para buscar valores expecificos

    public List<Denuncia> buscar(String categoria, String descricao){
        String filtro = "";
        String and = "";


        if (categoria instanceof String && !categoria.equals("")){
            filtro = filtro + and + Denuncia.CATEGORIA + "like" +categoria.trim() +"%' ";
            and = "and";
        }


        if (descricao instanceof String && !descricao.equals("")){
            filtro = filtro + and + Denuncia.CATEGORIA + "like" +descricao.trim() +"%' ";
            and = "and";
        }
        //ultimo null é a ordem da lista sempre com o espaço depoois do aspas
        Cursor c = db.query(Denuncia.TABELA,Denuncia.COLUNAS,filtro,null,null,null,null,Denuncia.ID+" desc");

        List<Denuncia> denuncias = new ArrayList<Denuncia>();
        if(c.moveToFirst()){
            do{
                Denuncia  denuncia = new Denuncia();
                denuncia.setId(c.getLong(c.getColumnIndex(Denuncia.ID)));
                denuncia.setCategoria(c.getString(c.getColumnIndex(Denuncia.CATEGORIA)));
                denuncia.setDescricao(c.getString(c.getColumnIndex(Denuncia.DESCRICAO)));
                denuncia.setFoto(c.getString(c.getColumnIndex(Denuncia.FOTO)));
                denuncia.setLatitude(c.getString(c.getColumnIndex(Denuncia.LATITUDE)));
                denuncia.setLongitude(c.getString(c.getColumnIndex(Denuncia.LONGITUDE)));
                denuncia.setData(c.getString(c.getColumnIndex(Denuncia.DATA)));

                Log.i("lista",denuncia.getCategoria());
                Log.i("lista",denuncia.getDescricao());
                Log.i("lista",denuncia.getFoto());
                Log.i("lista",denuncia.getLatitude());
                Log.i("lista",denuncia.getLongitude());


                denuncias.add(denuncia);
            }while (c.moveToNext());
        }
        return denuncias;
    }



}


