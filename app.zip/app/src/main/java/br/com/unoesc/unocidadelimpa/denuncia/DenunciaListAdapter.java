package br.com.unoesc.unocidadelimpa.denuncia;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import br.com.unoesc.unocidadelimpa.R;

/**
 * Created by vagner on 23/11/16.
 */
public class DenunciaListAdapter extends ArrayAdapter<Denuncia> {
    int layout;
    Context context;
    List<Denuncia> denunciaa;
    Bitmap bmimage;

    public DenunciaListAdapter(Context context, int layout, List<Denuncia> denuncias) {
        super(context, layout, denuncias);
        this.layout = layout;
        this.context = context;
        this.denunciaa = denuncias;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(layout,null);

        TextView tvCategoria = (TextView) view.findViewById(R.id.fragment_denuncia_list_tvCategoria);
        TextView tvDescricao = (TextView) view.findViewById(R.id.fragment_denuncia_list_tvDescricao);
        TextView tvLatidude = (TextView) view.findViewById(R.id.fragment_denuncia_list_tvLatitude);
        TextView tvLongitude = (TextView) view.findViewById(R.id.fragment_denuncia_list_tvLongitude);
        ImageView imfoto = (ImageView) view.findViewById(R.id.fragment_denuncia_list_imFoto);
        TextView tvdata = (TextView) view.findViewById(R.id.fragment_denuncia_list_tvData);




        final Denuncia denuncia = denunciaa.get(position);
        tvDescricao.setText(denuncia.getDescricao());
        tvCategoria.setText(denuncia.getCategoria());
        tvLatidude.setText(denuncia.getLatitude());
        tvLongitude.setText(denuncia.getLongitude());
        tvdata.setText(denuncia.getData());

        //decodifica e set a imagem
        byte[] bytarray = Base64.decode(denuncia.getFoto(), Base64.DEFAULT);
        bmimage= BitmapFactory.decodeByteArray(bytarray, 0 ,bytarray.length);
        imfoto.setImageBitmap(bmimage);





        return view;
    }
}
